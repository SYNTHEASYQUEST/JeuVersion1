﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonTest : MonoBehaviour
{
       public AudioSource frequence1;  //création d'un objet de type audio Source
    
    

public void C_Note_Play()
    {
        frequence1.Play();
    }



}
